<section class="footer-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="divider">
                    <span class="divider__circle"></span>
                </div>
            </div>
        </div>
        <div class="copyright-content row">
            <div class="col-lg-6">
                <p class="copy__desc">
                    &copy; <?php echo e(date('Y')); ?> Bitcon. All Rights Reserved.
                </p>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\bug-free-invention\resources\views/partials/footer.blade.php ENDPATH**/ ?>