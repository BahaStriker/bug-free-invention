<div class="loader-container">
    <div class="loader-ripple">
        <div></div>
        <div></div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\bug-free-invention\resources\views/partials/loader.blade.php ENDPATH**/ ?>